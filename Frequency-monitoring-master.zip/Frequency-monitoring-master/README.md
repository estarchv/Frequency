# semantic-monitoring
Use frequency temporal logic to describe the fault pattern
